//
//  ImageViewCell.swift
//  Virtual Tourist
//
//  Created by Abdulla Aseed on 16/03/1441 AH.
//  Copyright © 1441 Abdulla Alsahli. All rights reserved.
//

import Foundation
import UIKit

class ImageViewCell : UICollectionViewCell{
    
    static let identifier = "CollectionCell"
    @IBOutlet weak var imageCell: UIImageView!
}
